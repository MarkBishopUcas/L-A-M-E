"""
agent_hub.py — Universal AI PC Agent Hub
Supports: Claude API, Gemini, ChatGPT, DeepSeek, Grok, Claude Desktop App
Automatically falls back through your configured providers, passing full context forward.

Build into a .exe by running build.bat on Windows.
Move mouse to TOP-LEFT corner at any time to emergency stop.
"""

# ── DPI fix must be absolutely first ─────────────────────────────────────────
import ctypes
try:    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try: ctypes.windll.user32.SetProcessDPIAware()
    except Exception: pass

import os, sys, re, base64, time, traceback, subprocess, threading, json, atexit
from collections import deque
from datetime import datetime
from io import BytesIO
import tkinter as tk
from tkinter import filedialog, messagebox

# ── Resource path helper (works both from source and PyInstaller .exe) ────────
def resource_path(rel):
    base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)

# ── Config / log paths ────────────────────────────────────────────────────────
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_hub_config.json")
LOG_FILE    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_hub_log.txt")
IMAGES_DIR  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "images")

# ── Agent constants ───────────────────────────────────────────────────────────
SCREENSHOT_SCALE      = 0.5
MAX_STEPS             = 60
MOVE_DURATION         = 0.3
CONFIDENCE_THRESHOLD  = 70
RESPONSE_TIMEOUT      = 180
RESPONSE_SETTLE_TIME  = 3.0
IMG_CONFIDENCE        = 0.8
CLAUDE_WINDOW_TITLE   = "Claude"

GEMINI_MODEL_CHAIN = [
    ("gemini-2.5-flash-lite", 5.0),
    ("gemini-2.5-flash",      7.0),
    ("gemini-2.5-pro",        13.0),
]

OPENAI_COMPATIBLE = {
    "chatgpt":  ("https://api.openai.com/v1",   "gpt-4o"),
    "deepseek": ("https://api.deepseek.com/v1", "deepseek-chat"),
    "grok":     ("https://api.x.ai/v1",         "grok-2-vision-1212"),
}

PROVIDER_LABELS = {
    "claude_api": "Claude API",
    "gemini":     "Google Gemini",
    "chatgpt":    "ChatGPT (OpenAI)",
    "deepseek":   "DeepSeek",
    "grok":       "Grok (xAI)",
    "claude_app": "Claude Desktop App",
}

SYSTEM_PROMPT = """You are an AI agent directly controlling a Windows 11 PC using Python and pyautogui.
The screenshot shows the CURRENT STATE OF THE PC SCREEN you are controlling.
YOU issue the commands. Nothing happens unless YOU output commands.
You are not watching someone else — YOU ARE the controller.

RESPONSE FORMAT — always use this exact structure:

REASON: <one sentence: what you see on the PC screen and what you will do>
CONFIDENCE: <0-100: how confident you are>
ACTIONS:
<command1>
<command2>
<command3>

COORDINATE SYSTEM: The screenshot uses chess-style grid notation.
Columns are labeled A, B, C, ... (left to right), rows labeled 1, 2, 3, ... (top to bottom).
Grid lines appear every 25 pixels. To convert: column letter index * 25 = x, (row - 1) * 25 = y.
Example: D5 = x=75, y=100. Always pass pixel values (integers) in commands.

AVAILABLE COMMANDS:
  click(x, y)                     left click
  right_click(x, y)               right click
  double_click(x, y)              double click
  middle_click(x, y)              middle click
  move(x, y)                      move mouse without clicking
  smooth_move(x, y, duration)     slow smooth move
  drag(x1, y1, x2, y2)           fast drag
  drag_slow(x1, y1, x2, y2)      slow drag for file drag-and-drop
  scroll(x, y, amount)            scroll (+ up, - down)
  scroll_horizontal(x, y, amount) horizontal scroll
  type("text")                    type text, \\n=enter \\t=tab
  type_fast("text")               paste via clipboard (faster for long text)
  key("key")                      single key e.g. key("enter") key("f5")
  chord("ctrl+s")                 key combo
  hold_key("key", seconds)        hold key down
  copy()                          ctrl+c
  paste()                         ctrl+v
  cut()                           ctrl+x
  set_clipboard("text")           put text in clipboard
  screenshot()                    take fresh screenshot
  wait(seconds)                   wait N seconds
  find_window("title")            bring window to front
  ()done                          task complete

RULES:
- Output ONLY the format above, nothing else
- Batch confident actions together
- Add screenshot() if CONFIDENCE < 70 or you need to see the result
- ()done as soon as task is complete
- Never repeat a failing command more than twice
- Do NOT screenshot unnecessarily

WINDOWS 11:
- Look for desktop icon first (double_click it)
- To open apps with search: key("win"), wait(1), type("app name"), wait(2), key("enter")
- NEVER click the taskbar search bar — always use key("win")
- After key("win") just type immediately, don't click anything
- Games never in Run dialog — use desktop icon or key("win")
- After opening any app: wait(2) then screenshot()"""

# ═════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ═════════════════════════════════════════════════════════════════════════════

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_config(cfg: dict):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        print(f"[CONFIG] Could not save: {e}")

# ═════════════════════════════════════════════════════════════════════════════
#  LOGGING
# ═════════════════════════════════════════════════════════════════════════════

_log_buffer   = deque(maxlen=200)
_log_callback = None

def log(msg: str):
    ts    = datetime.now().strftime("%H:%M:%S")
    entry = f"[{ts}] {msg}"
    print(entry)
    _log_buffer.append(entry)
    if _log_callback:
        try:    _log_callback(entry)
        except Exception: pass

def save_log():
    try:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"Agent Hub Log — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 60 + "\n")
            for line in _log_buffer:
                f.write(line + "\n")
    except Exception:
        pass

atexit.register(save_log)

# ═════════════════════════════════════════════════════════════════════════════
#  SCREENSHOT + CHESS GRID
# ═════════════════════════════════════════════════════════════════════════════

def take_screenshot():
    """Capture screen, scale, draw chess-notation grid, return (base64_str, sw, sh)."""
    from PIL import ImageGrab, ImageDraw
    img = ImageGrab.grab()
    w, h = img.size
    sw, sh = int(w * SCREENSHOT_SCALE), int(h * SCREENSHOT_SCALE)
    img = img.resize((sw, sh))
    draw = ImageDraw.Draw(img)
    grid_spacing = 25

    def col_label(i):
        L = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        return L[i] if i < 26 else L[(i // 26) - 1] + L[i % 26]

    for i, x in enumerate(range(0, sw, grid_spacing)):
        c = (255, 0, 0) if i % 2 == 0 else (0, 200, 0)
        draw.line([(x, 0), (x, sh)], fill=c, width=1)
        draw.text((x + 2, 2), col_label(i), fill=c)

    for i, y in enumerate(range(0, sh, grid_spacing)):
        c = (255, 0, 0) if i % 2 == 0 else (0, 200, 0)
        draw.line([(0, y), (sw, y)], fill=c, width=1)
        draw.text((2, y + 2), str(i + 1), fill=c)

    buf = BytesIO()
    img.save(buf, format="PNG")
    return base64.standard_b64encode(buf.getvalue()).decode("utf-8"), sw, sh

def scale(n: int) -> int:
    return int(n / SCREENSHOT_SCALE)

# ═════════════════════════════════════════════════════════════════════════════
#  CLAUDE DESKTOP APP HELPERS
# ═════════════════════════════════════════════════════════════════════════════

IMG_PATHS = {
    "copy_btn":    os.path.join(IMAGES_DIR, "claude_copy_btn.png"),
    "input_empty": os.path.join(IMAGES_DIR, "claude_input_empty.png"),
    "input_used":  os.path.join(IMAGES_DIR, "claude_input_used.png"),
    "new_chat":    os.path.join(IMAGES_DIR, "claude_new_chat_btn.png"),
    "send_btn":    os.path.join(IMAGES_DIR, "claude_send_btn.png"),
    "stop_btn":    os.path.join(IMAGES_DIR, "claude_stop_btn.png"),
}

def _img_find(key, confidence=None):
    import pyautogui
    try:    return pyautogui.locateCenterOnScreen(IMG_PATHS[key], confidence=confidence or IMG_CONFIDENCE)
    except Exception: return None

def _img_wait(key, timeout=10.0, confidence=None):
    t = time.time()
    while time.time() - t < timeout:
        loc = _img_find(key, confidence)
        if loc: return loc
        time.sleep(0.5)
    return None

def _img_wait_gone(key, timeout=180.0, confidence=None):
    t = time.time()
    while time.time() - t < timeout:
        if not _img_find(key, confidence): return True
        time.sleep(0.5)
    return False

def _claude_app_to_front():
    import pyautogui
    pyautogui.press("escape"); time.sleep(0.2)
    wins = pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE)
    if not wins: log("[ERROR] Claude desktop not found"); return False
    try:    wins[0].activate()
    except Exception: wins[0].maximize()
    time.sleep(0.3)
    return True

def _ensure_claude_app_open():
    import pyautogui
    if pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE):
        log("[CLAUDE APP] Already open"); return True
    log("[CLAUDE APP] Attempting to launch...")
    candidates = [
        os.path.expandvars(r"%LOCALAPPDATA%\AnthropicClaude\claude.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\claude\Claude.exe"),
        r"C:\Program Files\Claude\Claude.exe",
    ]
    for p in candidates:
        if os.path.exists(p):
            subprocess.Popen([p]); time.sleep(4); return True
    pyautogui.press("win"); time.sleep(1)
    pyautogui.typewrite("Claude", interval=0.08); time.sleep(1.5)
    pyautogui.press("enter"); time.sleep(4)
    if pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE):
        log("[CLAUDE APP] Launched via search"); return True
    log("[ERROR] Could not launch Claude desktop app"); return False

def _claude_app_new_chat():
    import pyautogui
    if not _claude_app_to_front(): return False
    time.sleep(0.3)
    loc = _img_find("new_chat")
    if loc: pyautogui.click(loc); time.sleep(1.0); return True
    pyautogui.hotkey("ctrl", "n"); time.sleep(1.0); return True

def _claude_app_send(screenshot_b64, prompt_text):
    import pyautogui, pyperclip
    if not _claude_app_to_front(): return False
    if screenshot_b64:
        temp = os.path.join(os.environ.get("TEMP", "."), "agent_ss.png")
        with open(temp, "wb") as f: f.write(base64.b64decode(screenshot_b64))
        ps = (f'Add-Type -AssemblyName System.Windows.Forms; '
              f'Add-Type -AssemblyName System.Drawing; '
              f'[System.Windows.Forms.Clipboard]::SetImage([System.Drawing.Image]::FromFile("{temp}"))')
        try: subprocess.run(["powershell", "-Command", ps], capture_output=True, timeout=8); time.sleep(0.4)
        except Exception as e: log(f"[WARN] img clipboard: {e}")
    for key in ["input_empty", "input_used"]:
        loc = _img_find(key, confidence=0.7)
        if loc: pyautogui.click(loc); time.sleep(0.3); break
    if screenshot_b64: pyautogui.hotkey("ctrl", "v"); time.sleep(0.8)
    pyperclip.copy(prompt_text); time.sleep(0.2)
    pyautogui.hotkey("ctrl", "v"); time.sleep(0.5)
    loc = _img_wait("send_btn", timeout=5.0, confidence=0.75)
    if loc: pyautogui.click(loc)
    else:   pyautogui.press("enter")
    return True

def _claude_app_wait_response():
    import pyautogui, pyperclip
    log("[CLAUDE APP] Waiting for response...")
    _img_wait("stop_btn", timeout=30.0, confidence=0.75)
    _img_wait_gone("stop_btn", timeout=RESPONSE_TIMEOUT, confidence=0.75)
    time.sleep(RESPONSE_SETTLE_TIME)
    sw, sh = pyautogui.size()
    hx, hy = sw // 2, int(sh * 0.55)
    pyautogui.moveTo(hx, hy, duration=0.4); time.sleep(0.8)
    copy_loc = None
    for yo in range(20, 200, 15):
        pyautogui.moveTo(hx, hy + yo, duration=0.1); time.sleep(0.2)
        copy_loc = _img_find("copy_btn", confidence=0.75)
        if copy_loc: break
    if copy_loc:
        pyautogui.click(copy_loc); time.sleep(0.4)
        text = pyperclip.paste()
        if "REASON" in text: return text
    log("[WARN] Copy btn fallback")
    pyautogui.hotkey("ctrl", "end"); time.sleep(0.5)
    pyautogui.moveTo(hx, hy, duration=0.3); time.sleep(0.6)
    for yo in range(20, 200, 10):
        pyautogui.moveTo(hx, hy + yo, duration=0.05); time.sleep(0.15)
        copy_loc = _img_find("copy_btn", confidence=0.7)
        if copy_loc:
            pyautogui.click(copy_loc); time.sleep(0.4)
            return pyperclip.paste()
    return ""

def _minimize_claude_app():
    import pyautogui
    wins = pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE)
    if wins: wins[0].minimize(); time.sleep(0.4)

def _restore_claude_app():
    import pyautogui
    wins = pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE)
    if wins:
        try:   wins[0].restore(); time.sleep(0.2); wins[0].activate()
        except Exception: pass
        time.sleep(0.2)

# ═════════════════════════════════════════════════════════════════════════════
#  COMMAND EXECUTION
# ═════════════════════════════════════════════════════════════════════════════

_DESKTOP_CMDS = (
    "click","right_click","double_click","middle_click","move","smooth_move",
    "drag","drag_slow","scroll","scroll_horizontal","type","type_fast","key",
    "chord","hold_key","copy","paste","cut","wait","find_window","set_clipboard",
)

def execute_command(cmd: str, using_claude_app: bool = False):
    """Execute one command. Returns (keep_going, needs_screenshot)."""
    import pyautogui, pyperclip
    cmd = cmd.strip()
    if not cmd: return True, False
    if cmd == "()done": log("[AGENT] Task complete!"); return False, False
    if cmd == "screenshot()": return True, True

    needs_min = using_claude_app and any(cmd.startswith(c) for c in _DESKTOP_CMDS)
    if needs_min: _minimize_claude_app()
    result = _raw_exec(cmd)
    if needs_min: _restore_claude_app()
    return result

def _raw_exec(cmd: str):
    import pyautogui, pyperclip

    if cmd == "copy()":  pyautogui.hotkey("ctrl","c"); return True, False
    if cmd == "paste()": pyautogui.hotkey("ctrl","v"); return True, False
    if cmd == "cut()":   pyautogui.hotkey("ctrl","x"); return True, False

    m = re.fullmatch(r"click\((\d+),\s*(\d+)\)", cmd)
    if m: pyautogui.click(scale(int(m.group(1))), scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r"right_click\((\d+),\s*(\d+)\)", cmd)
    if m: pyautogui.rightClick(scale(int(m.group(1))), scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r"double_click\((\d+),\s*(\d+)\)", cmd)
    if m: pyautogui.doubleClick(scale(int(m.group(1))), scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r"middle_click\((\d+),\s*(\d+)\)", cmd)
    if m: pyautogui.middleClick(scale(int(m.group(1))), scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r"move\((\d+),\s*(\d+)\)", cmd)
    if m: pyautogui.moveTo(scale(int(m.group(1))), scale(int(m.group(2))), duration=MOVE_DURATION); return True, False

    m = re.fullmatch(r"smooth_move\((\d+),\s*(\d+),\s*(\d+(?:\.\d+)?)\)", cmd)
    if m:
        pyautogui.moveTo(scale(int(m.group(1))), scale(int(m.group(2))),
                         duration=float(m.group(3)), tween=pyautogui.easeInOutQuad)
        return True, False

    m = re.fullmatch(r"drag\((\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)", cmd)
    if m:
        x1,y1 = scale(int(m.group(1))),scale(int(m.group(2)))
        x2,y2 = scale(int(m.group(3))),scale(int(m.group(4)))
        pyautogui.moveTo(x1,y1,duration=0.2); pyautogui.dragTo(x2,y2,duration=0.4,button="left")
        return True, False

    m = re.fullmatch(r"drag_slow\((\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)", cmd)
    if m:
        x1,y1 = scale(int(m.group(1))),scale(int(m.group(2)))
        x2,y2 = scale(int(m.group(3))),scale(int(m.group(4)))
        pyautogui.moveTo(x1,y1,duration=0.3); time.sleep(0.2)
        pyautogui.mouseDown(button="left"); time.sleep(0.3)
        pyautogui.moveTo(x2,y2,duration=1.2,tween=pyautogui.easeInOutQuad); time.sleep(0.2)
        pyautogui.mouseUp(button="left"); return True, False

    m = re.fullmatch(r"scroll\((\d+),\s*(\d+),\s*(-?\d+)\)", cmd)
    if m: pyautogui.scroll(int(m.group(3)),x=scale(int(m.group(1))),y=scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r"scroll_horizontal\((\d+),\s*(\d+),\s*(-?\d+)\)", cmd)
    if m: pyautogui.hscroll(int(m.group(3)),x=scale(int(m.group(1))),y=scale(int(m.group(2)))); return True, False

    m = re.fullmatch(r'type\("(.*)"\)', cmd, re.DOTALL)
    if m: pyautogui.typewrite(m.group(1).replace("\\n","\n").replace("\\t","\t"),interval=0.05); return True, False

    m = re.fullmatch(r'type_fast\("(.*)"\)', cmd, re.DOTALL)
    if m:
        pyperclip.copy(m.group(1).replace("\\n","\n").replace("\\t","\t"))
        time.sleep(0.1); pyautogui.hotkey("ctrl","v"); return True, False

    m = re.fullmatch(r'key\("(.+)"\)', cmd)
    if m: pyautogui.press(m.group(1)); return True, False

    m = re.fullmatch(r'chord\("(.+)"\)', cmd)
    if m: pyautogui.hotkey(*m.group(1).split("+")  ); return True, False

    m = re.fullmatch(r'hold_key\("(.+)",\s*(\d+(?:\.\d+)?)\)', cmd)
    if m:
        pyautogui.keyDown(m.group(1)); time.sleep(float(m.group(2))); pyautogui.keyUp(m.group(1))
        return True, False

    m = re.fullmatch(r'set_clipboard\("(.*)"\)', cmd, re.DOTALL)
    if m: pyperclip.copy(m.group(1)); return True, False

    m = re.fullmatch(r"wait\((\d+(?:\.\d+)?)\)", cmd)
    if m: time.sleep(float(m.group(1))); return True, False

    m = re.fullmatch(r'find_window\("(.+)"\)', cmd)
    if m:
        import pyautogui
        wins = pyautogui.getWindowsWithTitle(m.group(1))
        if wins:
            try:   wins[0].activate()
            except Exception: wins[0].maximize()
            time.sleep(0.3)
        else: log(f"  [WARN] No window: '{m.group(1)}'")
        return True, False

    log(f"  [WARN] Unrecognised: {cmd}")
    return True, False

# ═════════════════════════════════════════════════════════════════════════════
#  RESPONSE PARSER
# ═════════════════════════════════════════════════════════════════════════════

def parse_response(text: str):
    reason, confidence, commands = "No reason given", 100, []
    in_actions = False
    blocks = re.split(r"(?=REASON:)", text)
    last = blocks[-1] if blocks else text
    for line in last.strip().splitlines():
        line = line.strip()
        if line.startswith("REASON:"):    reason = line[7:].strip(); in_actions = False
        elif line.startswith("CONFIDENCE:"):
            try:    confidence = int(re.search(r"\d+", line).group())
            except Exception: confidence = 100
        elif line.startswith("ACTIONS:"): in_actions = True
        elif in_actions and line:
            if line.startswith("REASON:"): break
            commands.append(line)
    if not commands:
        for line in last.splitlines():
            line = line.strip()
            if re.match(r"(click|double_click|right_click|type|key|chord|wait|screenshot|done|\(\)done)", line):
                commands.append(line)
    return reason, confidence, commands

# ═════════════════════════════════════════════════════════════════════════════
#  CONTEXT HANDOFF
# ═════════════════════════════════════════════════════════════════════════════

def build_handoff_context(task, history_summary, steps_done, last_reason):
    lines = [
        "=== CONTEXT HANDOFF FROM PREVIOUS AI PROVIDER ===",
        f"Original task: {task}",
        f"Steps completed so far: {steps_done}",
        f"Last known state: {last_reason}",
        "",
        "Recent action history:",
    ]
    for e in history_summary[-10:]:
        lines.append(f"  • {e}")
    lines += [
        "",
        "YOUR JOB: Continue the task above from where the previous agent left off.",
        "Take a screenshot first to see the current screen state.",
        "==================================================="
    ]
    return "\n".join(lines)

# ═════════════════════════════════════════════════════════════════════════════
#  PROVIDER BACKENDS
# ═════════════════════════════════════════════════════════════════════════════

class ClaudeAPIBackend:
    def __init__(self, api_key):
        import anthropic
        self.client  = anthropic.Anthropic(api_key=api_key)
        self.history = []

    def send(self, screenshot_b64, text):
        content = []
        if screenshot_b64:
            content.append({"type":"image","source":{"type":"base64","media_type":"image/png","data":screenshot_b64}})
        content.append({"type":"text","text":text})
        self.history.append({"role":"user","content":content})
        resp = self.client.messages.create(
            model="claude-opus-4-5", max_tokens=1024,
            system=SYSTEM_PROMPT, messages=self.history[-20:],
        )
        reply = resp.content[0].text.strip()
        self.history.append({"role":"assistant","content":[{"type":"text","text":reply}]})
        return reply

    def inject_context(self, ctx):
        self.history.append({"role":"user",     "content":[{"type":"text","text":ctx}]})
        self.history.append({"role":"assistant","content":[{"type":"text","text":"Understood. Taking a screenshot to see current state."}]})


class GeminiBackend:
    def __init__(self, api_key):
        from google import genai
        from google.genai import types
        self.genai     = genai
        self.types     = types
        self.client    = genai.Client(api_key=api_key)
        self.history   = []
        self.model_idx = 0
        self.exhausted = set()
        self._last     = 0.0

    def _model(self): return GEMINI_MODEL_CHAIN[self.model_idx]

    def _throttle(self):
        _, gap = self._model()
        elapsed = time.time() - self._last
        if elapsed < gap: time.sleep(gap - elapsed)

    def send(self, screenshot_b64, text):
        from google.genai import types
        parts = []
        if screenshot_b64:
            parts.append(types.Part.from_bytes(data=base64.b64decode(screenshot_b64), mime_type="image/png"))
        parts.append(types.Part.from_text(text=text))
        self.history.append(types.Content(role="user", parts=parts))
        self._drop_old_images()
        while True:
            name, _ = self._model()
            self._throttle()
            try:
                self._last = time.time()
                resp = self.client.models.generate_content(
                    model=name, contents=self.history[-20:],
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT, temperature=0.1, max_output_tokens=1024)
                )
                reply = resp.text.strip()
                self.history.append(types.Content(role="model", parts=[types.Part.from_text(text=reply)]))
                return reply
            except Exception as e:
                err = str(e)
                if "429" in err or "RESOURCE_EXHAUSTED" in err:
                    if any(k in err.lower() for k in ["per_day","daily","rpd"]):
                        self.exhausted.add(name)
                        nxt = next((i for i in range(self.model_idx+1, len(GEMINI_MODEL_CHAIN))
                                    if GEMINI_MODEL_CHAIN[i][0] not in self.exhausted), None)
                        if nxt is not None:
                            log(f"[GEMINI] Quota on {name} → {GEMINI_MODEL_CHAIN[nxt][0]}")
                            self.model_idx = nxt; continue
                        raise Exception("All Gemini models exhausted.")
                    m = re.search(r"retryDelay.*?(\d+)s", err)
                    w = int(m.group(1)) + 2 if m else 15
                    log(f"[GEMINI] Rate limit — waiting {w}s..."); time.sleep(w); continue
                raise

    def _drop_old_images(self, keep=2):
        from google.genai import types
        imgs = [i for i,m in enumerate(self.history)
                if m.role=="user" and any(hasattr(p,"inline_data") for p in m.parts)]
        for idx in imgs[:-keep]:
            self.history[idx] = types.Content(
                role="user",
                parts=[p for p in self.history[idx].parts if not hasattr(p,"inline_data")]
            )

    def inject_context(self, ctx):
        from google.genai import types
        self.history.append(types.Content(role="user",  parts=[types.Part.from_text(text=ctx)]))
        self.history.append(types.Content(role="model", parts=[types.Part.from_text(text="Understood. Continuing from handoff.")]))


class OpenAICompatibleBackend:
    """Works for ChatGPT, DeepSeek, Grok — all use OpenAI-compatible API."""
    def __init__(self, provider, api_key):
        import openai
        base_url, self.model = OPENAI_COMPATIBLE[provider]
        self.client  = openai.OpenAI(api_key=api_key, base_url=base_url)
        self.history = []

    def send(self, screenshot_b64, text):
        content = []
        if screenshot_b64:
            content.append({"type":"image_url","image_url":{"url":f"data:image/png;base64,{screenshot_b64}"}})
        content.append({"type":"text","text":text})
        self.history.append({"role":"user","content":content})
        msgs = [{"role":"system","content":SYSTEM_PROMPT}] + self.history[-20:]
        resp = self.client.chat.completions.create(model=self.model, messages=msgs, max_tokens=1024)
        reply = resp.choices[0].message.content.strip()
        self.history.append({"role":"assistant","content":reply})
        return reply

    def inject_context(self, ctx):
        self.history.append({"role":"user",     "content":ctx})
        self.history.append({"role":"assistant","content":"Understood. Continuing from handoff context."})


class ClaudeAppBackend:
    def __init__(self):
        self._inited = False

    def _init(self):
        if not _ensure_claude_app_open(): raise Exception("Could not open Claude desktop app")
        if not _claude_app_new_chat():    raise Exception("Could not start new chat")
        import pyautogui
        if not _img_wait("input_empty", timeout=10.0, confidence=0.7):
            log("[WARN] Input box not detected — continuing")
        time.sleep(0.5)
        self._inited = True

    def send(self, screenshot_b64, text):
        if not self._inited: self._init()
        if not _claude_app_send(screenshot_b64, text):
            raise Exception("Failed to send to Claude desktop app")
        return _claude_app_wait_response()

    def inject_context(self, ctx):
        if not self._inited: self._init()
        _claude_app_send(None, ctx)
        _claude_app_wait_response()

# ═════════════════════════════════════════════════════════════════════════════
#  AGENT RUNNER
# ═════════════════════════════════════════════════════════════════════════════

class AgentRunner:
    def __init__(self, config, stop_event, attached_image_b64=None):
        self.config          = config
        self.stop_event      = stop_event
        self.attached_image  = attached_image_b64
        self.history_summary = []
        self.steps_done      = 0
        self.last_reason     = "Task just started"

    def _build_chain(self):
        cfg, chain = self.config, []
        for pid in cfg.get("provider_order", []):
            key = cfg.get("keys", {}).get(pid, "").strip()
            try:
                if pid == "claude_api" and key:
                    chain.append((pid, ClaudeAPIBackend(key)))
                elif pid == "gemini" and key:
                    chain.append((pid, GeminiBackend(key)))
                elif pid in OPENAI_COMPATIBLE and key:
                    chain.append((pid, OpenAICompatibleBackend(pid, key)))
                elif pid == "claude_app" and cfg.get("use_claude_app"):
                    chain.append((pid, ClaudeAppBackend()))
            except Exception as e:
                log(f"[SETUP] {PROVIDER_LABELS.get(pid,pid)} init failed: {e}")
        return chain

    def run(self, task):
        chain = self._build_chain()
        if not chain:
            log("[ERROR] No providers configured. Please set up API keys."); return

        for idx, (pid, backend) in enumerate(chain):
            if self.stop_event.is_set(): break
            label = PROVIDER_LABELS.get(pid, pid)
            log(f"\n{'='*55}\n  [PROVIDER] {label}\n{'='*55}")

            if idx > 0 and self.steps_done > 0:
                ctx = build_handoff_context(task, self.history_summary, self.steps_done, self.last_reason)
                log(f"[HANDOFF] Passing context to {label}...")
                try:    backend.inject_context(ctx)
                except Exception as e: log(f"[WARN] Context inject failed: {e}")

            try:
                done = self._run_backend(task, backend, pid, is_fallback=(idx > 0))
                if done: break
            except Exception as e:
                log(f"[ERROR] {label} failed: {e}\n{traceback.format_exc()}")

        else:
            if not self.stop_event.is_set():
                log("[ERROR] All providers exhausted. Task could not be completed.")

    def _run_backend(self, task, backend, pid, is_fallback):
        import pyautogui
        real_w, real_h = pyautogui.size()
        sw = int(real_w * SCREENSHOT_SCALE)
        sh = int(real_h * SCREENSHOT_SCALE)
        using_app       = (pid == "claude_app")
        needs_ss        = True
        first_msg       = True
        ss_b64          = None
        consec_fails    = 0
        MAX_FAILS       = 3

        log(f"[AGENT] Screen: {real_w}x{real_h} → agent sees: {sw}x{sh}")

        while self.steps_done < MAX_STEPS:
            if self.stop_event.is_set():
                log("[AGENT] Stopped by user."); return True

            # Screenshot
            if needs_ss:
                log(f"[Step {self.steps_done+1}] Taking screenshot...")
                if using_app:
                    wins = pyautogui.getWindowsWithTitle(CLAUDE_WINDOW_TITLE)
                    if wins: wins[0].minimize(); time.sleep(0.6)
                    ss_b64, _, _ = take_screenshot()
                    if wins: wins[0].restore(); time.sleep(0.4); _claude_app_to_front()
                else:
                    ss_b64, _, _ = take_screenshot()
                needs_ss = False
                has_new_ss = True
            else:
                has_new_ss = False

            # Build prompt
            if first_msg and not is_fallback:
                prompt = (
                    f"TASK: {task}\n\n"
                    f"Current screen ({sw}x{sh}px — chess-notation grid):\n"
                    f"Columns A,B,C,... left→right, rows 1,2,3,... top→bottom, grid every 25px.\n"
                    + (f"[User also attached a reference image.]\n" if self.attached_image else "")
                    + "What is your first command?"
                )
            elif first_msg and is_fallback:
                prompt = (
                    f"Continuing task from handoff. Take a screenshot to see current state.\n"
                    f"Screen {sw}x{sh}px, chess-notation grid (25px spacing).\n"
                    f"What is your first command?"
                )
            elif has_new_ss:
                prompt = f"Updated screen ({sw}x{sh}px, chess grid). What is your next command?"
            else:
                prompt = "Commands executed. Same screen. What next? (use screenshot() if needed)"

            first_msg = False
            self.steps_done += 1
            log(f"[Step {self.steps_done}/{MAX_STEPS}] Querying {PROVIDER_LABELS.get(pid, pid)}...")

            # Send to backend
            img_out = ss_b64 if has_new_ss else None
            try:
                raw = backend.send(img_out, prompt)
            except Exception as e:
                log(f"[ERROR] Backend: {e}")
                consec_fails += 1
                if consec_fails >= MAX_FAILS:
                    log("[FALLBACK] Too many failures — switching provider")
                    return False
                time.sleep(2); continue

            consec_fails = 0
            reason, confidence, commands = parse_response(raw)
            log(f"  Reason:     {reason}")
            log(f"  Confidence: {confidence}%")
            log(f"  Actions:    {len(commands)} command(s)")
            self.last_reason = reason
            self.history_summary.append(f"Step {self.steps_done}: {reason}")

            # Retry if no commands
            if not commands:
                log("[WARN] No commands — asking to retry")
                retry = ("No valid commands found. Use ONLY this format:\n"
                         "REASON: <what you see>\nCONFIDENCE: <0-100>\nACTIONS:\n<command>\nContinue.")
                try:
                    raw = backend.send(None, retry)
                    reason, confidence, commands = parse_response(raw)
                except Exception: pass
                if not commands:
                    log("[ERROR] Still no commands after retry")
                    consec_fails += 1
                    if consec_fails >= MAX_FAILS: return False
                    continue

            if confidence < CONFIDENCE_THRESHOLD and "screenshot()" not in commands:
                commands.append("screenshot()")

            keep_going = True
            ss_requested = False
            for cmd in commands:
                if self.stop_event.is_set(): break
                log(f"    → {cmd}")
                keep_going, took_ss = execute_command(cmd, using_claude_app=using_app)
                if took_ss: ss_requested = True
                if not keep_going: break
                time.sleep(0.15)

            if not keep_going: return True   # ()done

            if ss_requested:
                time.sleep(1.0)
                needs_ss = True

            time.sleep(0.3)

        log(f"[AGENT] Step limit ({MAX_STEPS}) reached.")
        return True

# ═════════════════════════════════════════════════════════════════════════════
#  GUI THEME
# ═════════════════════════════════════════════════════════════════════════════

BG         = "#0b0b10"
PANEL      = "#13131a"
CARD       = "#1a1a24"
ACCENT     = "#7b68ee"     # medium slate blue — distinctive, not generic purple
ACCENT2    = "#38bdf8"     # sky blue
SUCCESS    = "#4ade80"
WARNING    = "#fbbf24"
DANGER     = "#f87171"
TEXT       = "#ddd8f0"
MUTED      = "#5a5570"
BORDER     = "#252535"
ENTRY_BG   = "#1e1c2e"

FT         = ("Segoe UI",    13)
FT_SM      = ("Segoe UI",    11)
FT_BOLD    = ("Segoe UI",    13, "bold")
FT_HEAD    = ("Segoe UI",    15, "bold")
FT_TITLE   = ("Segoe UI",    26, "bold")
FT_MONO    = ("Consolas",    12)
FT_BADGE   = ("Segoe UI",    11, "bold")

def _lbl(parent, text, font=FT, fg=TEXT, bg=None, **kw):
    return tk.Label(parent, text=text, font=font, fg=fg, bg=bg or BG, **kw)

def _btn(parent, text, cmd, color=ACCENT, fg="#ffffff", **kw):
    return tk.Button(parent, text=text, command=cmd,
                     bg=color, fg=fg, font=FT_BOLD, relief="flat",
                     cursor="hand2", activebackground=ACCENT2, activeforeground="#fff",
                     padx=16, pady=7, **kw)

def _entry(parent, textvariable=None, width=36, show=None):
    e = tk.Entry(parent, width=width, bg=ENTRY_BG, fg=TEXT,
                 insertbackground=TEXT, relief="flat", font=FT_MONO,
                 highlightthickness=1, highlightbackground=BORDER, highlightcolor=ACCENT)
    if textvariable: e.config(textvariable=textvariable)
    if show:         e.config(show=show)
    return e

# ═════════════════════════════════════════════════════════════════════════════
#  SETUP SCREEN
# ═════════════════════════════════════════════════════════════════════════════

PROVIDERS_META = [
    # (id,           display name,       placeholder,  tested)
    ("claude_api",   "Claude API",       "sk-ant-...",   True),
    ("gemini",       "Google Gemini",    "AIzaSy...",    True),
    ("chatgpt",      "ChatGPT (OpenAI)", "sk-...",       False),
    ("deepseek",     "DeepSeek",         "sk-...",       False),
    ("grok",         "Grok (xAI)",       "xai-...",      False),
]

class SetupScreen(tk.Frame):
    def __init__(self, master, on_done, existing_cfg=None):
        super().__init__(master, bg=BG)
        self.on_done      = on_done
        self.existing_cfg = existing_cfg or {}
        self._vars        = {}   # pid -> (BooleanVar, StringVar)
        self._build()

    def _build(self):
        # Thin accent stripe left
        tk.Frame(self, bg=ACCENT, width=5).pack(side="left", fill="y")

        scroll_outer = tk.Frame(self, bg=BG)
        scroll_outer.pack(side="left", fill="both", expand=True)

        canvas = tk.Canvas(scroll_outer, bg=BG, highlightthickness=0)
        vbar   = tk.Scrollbar(scroll_outer, orient="vertical", command=canvas.yview,
                               bg=PANEL, troughcolor=PANEL, bd=0)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_resize(e):
            canvas.itemconfig(win_id, width=e.width)
        def _on_frame(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
        canvas.bind("<Configure>", _on_resize)
        inner.bind("<Configure>", _on_frame)

        self._fill(inner)

    def _fill(self, f):
        pad = dict(padx=48)

        # Header
        hdr = tk.Frame(f, bg=BG)
        hdr.pack(fill="x", pady=(40, 0), **pad)
        _lbl(hdr, "AGENT HUB", font=FT_TITLE, fg=ACCENT).pack(anchor="w")
        _lbl(hdr, "Universal AI PC Agent", font=("Segoe UI", 12), fg=MUTED).pack(anchor="w", pady=(2,0))

        # Welcome message
        welcome_card = tk.Frame(f, bg=CARD, padx=20, pady=16)
        welcome_card.pack(fill="x", pady=(28, 0), **pad)
        _lbl(welcome_card, "Welcome! Give us a task, and we'll see what we can do.",
             font=FT_HEAD, fg=TEXT, bg=CARD).pack(anchor="w")
        _lbl(welcome_card, "First, tell us which API keys you have. We'll try them in order — if one fails, we move to the next.",
             font=FT_SM, fg=MUTED, bg=CARD, wraplength=560, justify="left").pack(anchor="w", pady=(6,0))

        # Provider section
        _lbl(f, "API Keys", font=FT_HEAD, fg=TEXT).pack(anchor="w", pady=(28, 4), **pad)
        _lbl(f, "Check the box next to each provider you have a key for, then paste your key.",
             font=FT_SM, fg=MUTED).pack(anchor="w", pady=(0, 10), **pad)

        providers_frame = tk.Frame(f, bg=BG)
        providers_frame.pack(fill="x", **pad)

        existing_keys  = self.existing_cfg.get("keys", {})
        existing_order = self.existing_cfg.get("provider_order", [])

        for pid, display, placeholder, tested in PROVIDERS_META:
            enabled_var = tk.BooleanVar(value=(pid in existing_order))
            key_var     = tk.StringVar(value=existing_keys.get(pid, ""))
            self._vars[pid] = (enabled_var, key_var)
            self._provider_row(providers_frame, pid, display, placeholder, enabled_var, key_var, tested)

        # Separator
        tk.Frame(f, bg=BORDER, height=1).pack(fill="x", pady=(24, 12), **pad)

        # Claude App fallback
        _lbl(f, "Last-Resort Fallback", font=FT_HEAD, fg=TEXT).pack(anchor="w", pady=(0, 4), **pad)
        _lbl(f, "If every API key fails or is exhausted, fall back to the Claude desktop app (uses image recognition).",
             font=FT_SM, fg=MUTED, wraplength=560, justify="left").pack(anchor="w", pady=(0, 10), **pad)

        app_card = tk.Frame(f, bg=CARD, padx=20, pady=14)
        app_card.pack(fill="x", pady=(0, 8), **pad)
        self._use_app_var = tk.BooleanVar(value=self.existing_cfg.get("use_claude_app", False))

        app_row = tk.Frame(app_card, bg=CARD)
        app_row.pack(fill="x")
        tk.Checkbutton(app_row, variable=self._use_app_var,
                       bg=CARD, fg=TEXT, selectcolor=ENTRY_BG,
                       activebackground=CARD, cursor="hand2",
                       highlightthickness=0).pack(side="left")
        _lbl(app_row, "Use Claude Desktop App as final fallback",
             bg=CARD, fg=TEXT).pack(side="left", padx=6)
        _lbl(app_row, "(requires the images/ folder next to this exe)",
             bg=CARD, fg=MUTED, font=FT_SM).pack(side="left", padx=4)

        # Bottom row
        bottom = tk.Frame(f, bg=BG)
        bottom.pack(fill="x", pady=(24, 40), **pad)
        _btn(bottom, "Save & Continue →", self._submit, color=ACCENT).pack(side="right")
        _lbl(bottom, "Keys saved locally in agent_hub_config.json", fg=MUTED, font=FT_SM).pack(side="left")

    def _provider_row(self, parent, pid, display, placeholder, enabled_var, key_var, tested):
        card = tk.Frame(parent, bg=CARD, padx=16, pady=16)
        card.pack(fill="x", pady=4)

        top = tk.Frame(card, bg=CARD)
        top.pack(fill="x")

        # Checkbox + name
        left = tk.Frame(top, bg=CARD)
        left.pack(side="left", padx=(0, 20))

        tk.Checkbutton(left, variable=enabled_var, bg=CARD, fg=TEXT,
                       selectcolor=ENTRY_BG, activebackground=CARD,
                       cursor="hand2", highlightthickness=0).pack(side="left")
        _lbl(left, display, bg=CARD, fg=TEXT, font=FT_BOLD).pack(side="left", padx=4)

        if not tested:
            _lbl(left, "untested", bg=CARD, fg=MUTED, font=FT_BADGE).pack(side="left", padx=2)

        # Key entry row
        right = tk.Frame(top, bg=CARD)
        right.pack(side="left", fill="x", expand=True)

        # Don't use textvariable — manage value manually so placeholder doesn't pollute key_var
        entry = tk.Entry(right, width=44, show="•",
                         bg=ENTRY_BG, fg=TEXT, insertbackground=TEXT,
                         relief="flat", font=FT_MONO,
                         highlightthickness=1, highlightbackground=BORDER, highlightcolor=ACCENT)
        entry.pack(side="left", ipady=5)

        # Populate: show saved key if we have one, otherwise show placeholder
        saved = key_var.get().strip()
        if saved:
            entry.insert(0, saved)
            entry.config(fg=TEXT, show="•")
        else:
            entry.insert(0, placeholder)
            entry.config(fg=MUTED, show="")

        def _focus_in(e, ent=entry, ph=placeholder, var=key_var):
            if ent.get() == ph:
                ent.delete(0, "end"); ent.config(fg=TEXT, show="•")
        def _focus_out(e, ent=entry, ph=placeholder, var=key_var):
            val = ent.get().strip()
            if val and val != ph:
                var.set(val)   # save real value into key_var
            else:
                ent.delete(0, "end"); ent.insert(0, ph); ent.config(fg=MUTED, show="")
                var.set("")

        entry.bind("<FocusIn>",  _focus_in)
        entry.bind("<FocusOut>", _focus_out)

        show_var = tk.BooleanVar(value=False)
        def _toggle(ent=entry, sv=show_var):
            sv.set(not sv.get())
            ent.config(show="" if sv.get() else "•")
        tk.Button(right, text="👁", command=_toggle,
                  bg=CARD, fg=MUTED, relief="flat", font=FT_SM,
                  cursor="hand2", activebackground=CARD, bd=0).pack(side="left", padx=6)

    def _submit(self):
        ph_map = {pid: ph for pid, _, ph, _ in PROVIDERS_META}
        keys, order = {}, []
        for pid, (enabled_var, key_var) in self._vars.items():
            raw = key_var.get().strip()
            if raw and raw != ph_map.get(pid, ""):
                keys[pid] = raw
            if enabled_var.get():
                order.append(pid)
        if self._use_app_var.get():
            order.append("claude_app")
        if not order:
            messagebox.showwarning("No providers", "Please enable at least one provider.")
            return
        cfg = {"keys": keys, "provider_order": order, "use_claude_app": self._use_app_var.get()}
        save_config(cfg)
        self.on_done(cfg)

# ═════════════════════════════════════════════════════════════════════════════
#  MAIN SCREEN
# ═════════════════════════════════════════════════════════════════════════════

class MainScreen(tk.Frame):
    def __init__(self, master, config, on_reconfigure):
        super().__init__(master, bg=BG)
        self.config         = config
        self.on_reconfigure = on_reconfigure
        self.stop_event     = threading.Event()
        self.agent_thread   = None
        self.attached_b64   = None
        self._build()
        global _log_callback
        _log_callback = self._append_log

    def _build(self):
        # ── Top bar ───────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=PANEL, height=50)
        bar.pack(fill="x"); bar.pack_propagate(False)
        tk.Frame(bar, bg=ACCENT, width=5).pack(side="left", fill="y")
        _lbl(bar, "AGENT HUB", font=("Segoe UI", 13, "bold"), fg=ACCENT, bg=PANEL).pack(side="left", padx=14)
        self._badge = _lbl(bar, self._primary_label(), font=FT_BADGE, fg="#000", bg=ACCENT2)
        self._badge.pack(side="left", ipadx=8, ipady=3)
        _btn(bar, "⚙ Reconfigure", self.on_reconfigure, color=BORDER, fg=MUTED).pack(side="right", padx=10, pady=8)

        # ── Body ──────────────────────────────────────────────────────────
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)

        # Left: log
        log_pane = tk.Frame(body, bg=PANEL)
        log_pane.pack(side="left", fill="both", expand=True)

        log_hdr = tk.Frame(log_pane, bg=PANEL, height=32)
        log_hdr.pack(fill="x"); log_hdr.pack_propagate(False)
        _lbl(log_hdr, "  LIVE LOG", font=FT_BADGE, fg=MUTED, bg=PANEL).pack(side="left", pady=8)
        _btn(log_hdr, "Clear", lambda: self._clear_log(), color=PANEL, fg=MUTED).pack(side="right", padx=8, pady=4)

        self.log_box = tk.Text(log_pane, bg=PANEL, fg=SUCCESS, font=FT_MONO,
                               relief="flat", wrap="word", state="disabled",
                               padx=10, pady=6, selectbackground=ACCENT)
        sb = tk.Scrollbar(log_pane, command=self.log_box.yview, bg=PANEL, troughcolor=PANEL, bd=0)
        self.log_box.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_box.pack(fill="both", expand=True)

        # Vertical divider
        tk.Frame(body, bg=BORDER, width=1).pack(side="left", fill="y")

        # Right: controls
        ctrl = tk.Frame(body, bg=BG, width=330)
        ctrl.pack(side="right", fill="y")
        ctrl.pack_propagate(False)

        inner = tk.Frame(ctrl, bg=BG, padx=22, pady=22)
        inner.pack(fill="both", expand=True)

        _lbl(inner, "What should I do?", font=FT_HEAD).pack(anchor="w")
        _lbl(inner, "I'll control your PC to complete it — or ask for a screenshot.",
             font=FT_SM, fg=MUTED, wraplength=280, justify="left").pack(anchor="w", pady=(3,14))

        self.task_box = tk.Text(inner, height=6, bg=ENTRY_BG, fg=TEXT,
                                insertbackground=TEXT, font=FT,
                                relief="flat", wrap="word", padx=10, pady=8,
                                highlightthickness=1, highlightbackground=BORDER, highlightcolor=ACCENT)
        self.task_box.pack(fill="x", pady=(0,10))
        self.task_box.bind("<Control-Return>", lambda e: self._start())

        # Attach image
        at = tk.Frame(inner, bg=BG)
        at.pack(fill="x", pady=(0,12))
        _btn(at, "📎 Attach Image", self._attach, color=CARD, fg=TEXT).pack(side="left")
        self._attach_lbl = _lbl(at, " no image", fg=MUTED, font=FT_SM)
        self._attach_lbl.pack(side="left")
        tk.Button(at, text="✕", command=self._clear_attach,
                  bg=BG, fg=MUTED, relief="flat", font=FT_SM, cursor="hand2",
                  activebackground=BG, bd=0).pack(side="left", padx=2)

        self.preview = tk.Label(inner, bg=BG, text="")
        self.preview.pack(fill="x", pady=(0,10))

        # Run / Stop
        br = tk.Frame(inner, bg=BG)
        br.pack(fill="x", pady=(0,8))
        self.run_btn  = _btn(br, "▶  Run Task", self._start, color=ACCENT)
        self.run_btn.pack(side="left", fill="x", expand=True)
        self.stop_btn = _btn(br, "■", self._stop, color=DANGER)
        self.stop_btn.pack(side="left", padx=(6,0))
        self.stop_btn.config(state="disabled")

        _lbl(inner, "Mouse to TOP-LEFT = emergency stop", fg=MUTED, font=FT_SM).pack(anchor="w", pady=(4,0))

        # Provider chain
        tk.Frame(inner, bg=BORDER, height=1).pack(fill="x", pady=14)
        _lbl(inner, "Provider Chain", font=FT_BADGE, fg=MUTED).pack(anchor="w", pady=(0,6))
        self.chain_frame = tk.Frame(inner, bg=BG)
        self.chain_frame.pack(fill="x")
        self._draw_chain()

    def _primary_label(self):
        order = self.config.get("provider_order", [])
        return PROVIDER_LABELS.get(order[0], order[0]) if order else "No provider"

    def _draw_chain(self):
        for w in self.chain_frame.winfo_children(): w.destroy()
        order = self.config.get("provider_order", [])
        tags  = ["primary", "fallback", "backup", "backup", "backup", "backup"]
        colors= [ACCENT,    ACCENT2,    MUTED,     MUTED,     MUTED,    MUTED]
        for i, pid in enumerate(order):
            row = tk.Frame(self.chain_frame, bg=BG)
            row.pack(fill="x", pady=2)
            c = colors[i] if i < len(colors) else MUTED
            t = tags[i]   if i < len(tags)   else "backup"
            _lbl(row, f"{i+1}.", fg=c, font=FT_BADGE).pack(side="left")
            _lbl(row, PROVIDER_LABELS.get(pid, pid), fg=c, font=FT_SM).pack(side="left", padx=4)
            _lbl(row, t, fg=c, font=FT_BADGE).pack(side="right")

    def _append_log(self, entry):
        def _do():
            self.log_box.config(state="normal")
            tag = ("err"  if any(x in entry for x in ["[ERROR]","[CRASH]"]) else
                   "warn" if "[WARN]"     in entry else
                   "info" if any(x in entry for x in ["[AGENT]","[PROVIDER]","[HUB]"]) else
                   "cmd"  if "→"          in entry else "ok")
            self.log_box.tag_configure("err",  foreground=DANGER)
            self.log_box.tag_configure("warn", foreground=WARNING)
            self.log_box.tag_configure("info", foreground=ACCENT)
            self.log_box.tag_configure("cmd",  foreground=ACCENT2)
            self.log_box.tag_configure("ok",   foreground=SUCCESS)
            self.log_box.insert("end", entry + "\n", tag)
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.after(0, _do)

    def _clear_log(self):
        self.log_box.config(state="normal")
        self.log_box.delete("1.0","end")
        self.log_box.config(state="disabled")

    def _attach(self):
        path = filedialog.askopenfilename(
            title="Attach reference image",
            filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.gif *.webp"),("All","*.*")]
        )
        if not path: return
        try:
            from PIL import Image, ImageTk
            img = Image.open(path)
            buf = BytesIO(); img.save(buf, format="PNG")
            self.attached_b64 = base64.standard_b64encode(buf.getvalue()).decode()
            img.thumbnail((280, 110))
            photo = ImageTk.PhotoImage(img)
            self.preview.config(image=photo, text="")
            self.preview.image = photo
            self._attach_lbl.config(text=f" {os.path.basename(path)}", fg=SUCCESS)
        except Exception as e:
            messagebox.showerror("Image error", str(e))

    def _clear_attach(self):
        self.attached_b64 = None
        self.preview.config(image="", text="")
        try: self.preview.image = None
        except Exception: pass
        self._attach_lbl.config(text=" no image", fg=MUTED)

    def _start(self):
        task = self.task_box.get("1.0","end").strip()
        if not task:
            messagebox.showwarning("No task","Please enter a task first."); return
        if self.agent_thread and self.agent_thread.is_alive():
            messagebox.showinfo("Busy","Agent is already running."); return
        self.stop_event.clear()
        self.run_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._clear_log()
        runner = AgentRunner(self.config, self.stop_event, self.attached_b64)
        def _go():
            try:    runner.run(task)
            except Exception as e: log(f"[CRASH] {e}\n{traceback.format_exc()}")
            finally: self.after(0, self._done)
        self.agent_thread = threading.Thread(target=_go, daemon=True)
        self.agent_thread.start()

    def _stop(self):
        self.stop_event.set()
        log("[USER] Stop requested...")

    def _done(self):
        self.run_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        log("[AGENT] Ready for next task.")

# ═════════════════════════════════════════════════════════════════════════════
#  APP ROOT
# ═════════════════════════════════════════════════════════════════════════════

class AgentHubApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.withdraw()   # hide briefly to prevent phantom blank window flash
        # Detect Windows display scaling and set tk scaling to match
        try:
            import ctypes
            awareness = ctypes.c_int()
            ctypes.windll.shcore.GetScaleFactorForDevice(0)
            dpi = ctypes.windll.user32.GetDpiForSystem()
            scale = dpi / 96.0
            self.tk.call('tk', 'scaling', scale)
        except Exception:
            pass
        super().__init__()
        self.title("Agent Hub")
        self.geometry("1100x700")
        self.minsize(820, 560)
        self.configure(bg=BG)
        try:
            ico = resource_path("icon.ico")
            if os.path.exists(ico): self.iconbitmap(ico)
        except Exception: pass
        self._screen = None
        cfg = load_config()
        if cfg.get("provider_order"):
            self._main(cfg)
        else:
            self._setup()
        self.deiconify()  # show now that everything is ready

    def _clear(self):
        if self._screen: self._screen.destroy()

    def _setup(self, existing_cfg=None):
        self._clear()
        cfg = existing_cfg or load_config()
        self._screen = SetupScreen(self, on_done=self._main, existing_cfg=cfg)
        self._screen.pack(fill="both", expand=True)

    def _main(self, cfg):
        self._clear()
        self._screen = MainScreen(self, config=cfg, on_reconfigure=lambda: self._setup(cfg))
        self._screen.pack(fill="both", expand=True)
        chain_str = " → ".join(PROVIDER_LABELS.get(p,p) for p in cfg.get("provider_order",[]))
        log(f"[HUB] Provider chain: {chain_str}")
        log("[HUB] Welcome! Give me a task and I'll get to work.")

# ═════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = AgentHubApp()
    app.mainloop()
