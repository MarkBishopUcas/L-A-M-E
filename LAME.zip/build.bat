@echo off
title Agent Hub — EXE Builder
echo.
echo ============================================================
echo   Agent Hub ^| Building .exe with PyInstaller
echo ============================================================
echo.

:: ── 1. Check Python ──────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install from https://python.org
    pause & exit /b 1
)

:: ── 2. Install / upgrade dependencies ────────────────────────
echo [1/4] Installing dependencies...
python -m pip install --upgrade pip --quiet
python -m pip install ^
    pyinstaller ^
    anthropic ^
    google-genai ^
    openai ^
    pyautogui ^
    pillow ^
    pyperclip ^
    --quiet

if errorlevel 1 (
    echo [ERROR] pip install failed. Check your internet connection.
    pause & exit /b 1
)
echo [OK] Dependencies installed.
echo.

:: ── 3. Build with PyInstaller ─────────────────────────────────
echo [2/4] Building exe (this takes 1-2 minutes)...

:: Use "python -m PyInstaller" so it works even when Scripts\ is not on PATH
if exist "icon.ico" (
    python -m PyInstaller ^
        --onefile ^
        --windowed ^
        --name "AgentHub" ^
        --icon "icon.ico" ^
        --hidden-import anthropic ^
        --hidden-import google.genai ^
        --hidden-import openai ^
        --hidden-import pyautogui ^
        --hidden-import PIL ^
        --hidden-import PIL.ImageGrab ^
        --hidden-import PIL.ImageDraw ^
        --hidden-import PIL.Image ^
        --hidden-import PIL.ImageTk ^
        --hidden-import pyperclip ^
        --hidden-import tkinter ^
        --hidden-import tkinter.filedialog ^
        --hidden-import tkinter.messagebox ^
        --collect-all anthropic ^
        --collect-all google.genai ^
        --collect-all openai ^
        --noconfirm ^
        agent_hub.py
) else (
    echo [INFO] No icon.ico found — building without custom icon.
    python -m PyInstaller ^
        --onefile ^
        --windowed ^
        --name "AgentHub" ^
        --hidden-import anthropic ^
        --hidden-import google.genai ^
        --hidden-import openai ^
        --hidden-import pyautogui ^
        --hidden-import PIL ^
        --hidden-import PIL.ImageGrab ^
        --hidden-import PIL.ImageDraw ^
        --hidden-import PIL.Image ^
        --hidden-import PIL.ImageTk ^
        --hidden-import pyperclip ^
        --hidden-import tkinter ^
        --hidden-import tkinter.filedialog ^
        --hidden-import tkinter.messagebox ^
        --collect-all anthropic ^
        --collect-all google.genai ^
        --collect-all openai ^
        --noconfirm ^
        agent_hub.py
)

if errorlevel 1 (
    echo [ERROR] PyInstaller build failed. See output above.
    pause & exit /b 1
)
echo [OK] Build complete.
echo.

:: ── 4. Copy assets into dist folder ──────────────────────────
echo [3/4] Copying assets...

if not exist "dist\AgentHub" mkdir "dist\AgentHub"

:: Copy images folder if it exists (needed for Claude App fallback)
if exist "images" (
    xcopy /E /I /Y "images" "dist\images" >nul
    echo [OK] Copied images\ folder.
) else (
    echo [WARN] No images\ folder found — Claude App fallback won't work without it.
)

:: Copy icon if present
if exist "icon.ico" (
    copy /Y "icon.ico" "dist\icon.ico" >nul
    echo [OK] Copied icon.ico
)

echo.
echo [4/4] Done!
echo.
echo ============================================================
echo   YOUR EXE IS READY:
echo   dist\AgentHub.exe
echo.
echo   To share with friends, send them:
echo     - AgentHub.exe
echo     - images\  folder (only needed if they want Claude App fallback)
echo.
echo   The exe saves config to agent_hub_config.json next to itself.
echo   Keys are stored locally — never sent anywhere except the APIs.
echo ============================================================
echo.
pause
